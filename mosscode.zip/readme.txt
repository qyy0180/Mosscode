Moss.exe is for window systems.

moss3.c, moss4.c, and moss5.c are source codes for linux systems.
Format:  
./moss3 graph_dataset Bmax StdErrMax
./moss4 graph_dataset Bmax StdErrMax
./moss5 graph_dataset Bmax StdErrMax

Example: ./moss5 CA-HepTh.txt.gz 100000 0.01

More datasets are available on http://nskeylab.xjtu.edu.cn/people/phwang/code/