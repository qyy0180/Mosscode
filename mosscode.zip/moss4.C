#include <iostream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <inttypes.h>
#include <limits.h>
#include <cmath>
#include <queue>
#include <stack>
#include <stdio.h>
#include <ext/hash_map>
#include <ext/hash_set>
#include "RandomLib/Random.hpp"

#define _FLOAT long double
#define _PTYPE float
#define _FLAGTYPE uint8_t

#define DIRECTED_GRAPH_EDGE_FLAG 0
#define INVALID_EDGE_FLAG -1

//largest positive value an int32_t can hold.
#define INT32_MAX 0x7fffffffL

//largest negative value an int32_t can hold.
#define INT32_MIN (-INT32_MAX - 1L) 

int32_t directedGFlag=0;
int32_t independence_cost = 1;
int32_t maxOutdegree = 0;

using namespace __gnu_cxx; 
using namespace std;
RandomLib::Random rnd;		// r created with random seed

template <typename data_type>
inline data_type myrand(data_type max) {
	return rnd.IntegerC<data_type>(0,max-1);
}

inline double myUnifrand() {
	// r.Fixed() is in the interval (0, 1)
	return rnd.Fixed();
}

inline int32_t bineary_search(int64_t * weights, int32_t len, int64_t search_value) {
	int32_t i;
	int32_t head, tail, mid;

	i=0;

	while(weights[i]==0){
		i++;
	}
	head = i;
	
	if(search_value<=weights[head]){
		return head;
	}
	head = 0;
	tail = len - 1;
	while(tail - head > 1){
		mid = (head + tail)/2;
		if (search_value == weights[mid]){
			break;
		}
		if (search_value < weights[mid]){
			tail = mid;
		}
		else{
			head = mid+1;
		}
	}
	if(tail == head){
		return head;
	}
	if(tail - head == 1){
		if (search_value<=weights[head]){
			return head;
		}
		else{
			return tail;
		}
	}
	while(weights[mid] == search_value){
		mid--;
	}
	return mid+1;
}



#define MIN(a,b) ((a)>(b)?(b):(a))
#define MAX(a,b) ((a)<(b)?(b):(a))
#define ABSMAX(a,b) (abs(a)<abs(b)?(b):(a))



struct edge {
  int32_t u,v;
  _PTYPE p;
  int32_t duv;
  int32_t dvu;
  int32_t* neighbor_u_v;
  int32_t* neighbor_v_u;
};

struct vertex {
	_FLAGTYPE flag;
	int32_t  deg, undirected_deg;
	int32_t  indeg, outdeg;
	int32_t  neigsize;
    int32_t id;
	int64_t* neighbor_weights;
	int64_t* neighbor_weights_u;
	edge** edges;
};

void *zrealloc(void *ptr, size_t newsize, size_t oldsize) {
  int8_t *p = (int8_t *) realloc(ptr,newsize);
  if (p == NULL) {
      cerr << "Could not allocate "<<((_FLOAT)(newsize))/(1024*1024)<<"Kbytes. Aborting."<<endl;
      abort();
  }
  memset(p+oldsize,0,newsize - oldsize);
  return (void*)p;
}

void *zalloc(size_t newsize) {
  int8_t *p = (int8_t *) malloc(newsize);
  if (p == NULL) {
      cerr << "Could not allocate "<<((_FLOAT)(newsize))/(1024*1024)<<"Kbytes. Aborting."<<endl;
      abort();
  }
  memset(p,0,newsize);
  return (void*)p;
}

class Gdb {
private:
  int32_t reservedspaceE;
  int32_t reservedspaceV;
  int32_t edgeindex;
  int32_t N;
  int32_t _MAXID;
  int32_t noedges;
  int32_t i_idE, i_idV;
  
  vertex *V;
  edge *E;

  hash_set<int64_t> edge_set;
  hash_map<int,int> matrix_to_motif4class;
  
public:
  Gdb() {
  }
  ~Gdb(){
  	vertex *v;
	vertex_iterator_start();
	while ((v = next_vertex()) != NULL) 
	{  	
	  	free(v->edges);
		free(v->neighbor_weights);
		free(v->neighbor_weights_u);
	}
  	free(V);
	free(E);
  }

   void set_matrix_to_motif4class(){
 	    FILE *fp;
 	    int i,j;
 	    fp = fopen("matrix_motif4","r");
 	    while(!feof(fp)){
 	       if(fscanf(fp,"%d\t%d\n",&i,&j) == 2){
                matrix_to_motif4class[i] = j;
 	       }
 	    }
		fclose(fp);
  }


  void init(int32_t p_reservedspaceE, int32_t p_reservedspaceV) {
    edgeindex = 0;
    N = 0;
    _MAXID = 0;
	noedges = 0;
    reservedspaceE = p_reservedspaceE;
    reservedspaceV = p_reservedspaceV;
    E = (edge *) zalloc(reservedspaceE * sizeof(edge));
    V = (vertex *) zalloc(reservedspaceV * sizeof(vertex));
	set_matrix_to_motif4class();
  }


    void updatevertex(int32_t u) {
    if (u >= reservedspaceV) {
      cerr << "Fatal Error: More vertices than previously allocated = "<<reservedspaceV<<endl;
      abort();
    }
    _MAXID = MAX(_MAXID,u);
    if (V[u].edges == NULL) {
      N++;
      V[u].neigsize = 4;
      V[u].edges = (edge**) zalloc(V[u].neigsize*sizeof(edge*));
	  V[u].neighbor_weights = (int64_t*) zalloc(V[u].neigsize*sizeof(int64_t));
	  V[u].neighbor_weights_u = (int64_t*) zalloc(V[u].neigsize*sizeof(int64_t));

    }
    if (V[u].deg >= V[u].neigsize) {
	  V[u].edges = (edge**) zrealloc(V[u].edges, (V[u].neigsize*2)*sizeof(edge*), V[u].neigsize*sizeof(edge*));
	  V[u].neighbor_weights = (int64_t*) zrealloc(V[u].neighbor_weights, (V[u].neigsize*2)*sizeof(int64_t), V[u].neigsize*sizeof(int64_t));
	  V[u].neighbor_weights_u = (int64_t*) zrealloc(V[u].neighbor_weights_u, (V[u].neigsize*2)*sizeof(int64_t), V[u].neigsize*sizeof(int64_t));
	  V[u].neigsize *= 2;
    }
    V[u].id = u;
  }
  inline vertex* getvertex(int32_t u) {
    return (exists(u))? &V[u] : NULL;
  }
  
  inline void edge_iterator_start() {
    i_idE = 0;
  }
  
  inline bool exists_e(int32_t id) {
	  return ((id < edgeindex)? ((E[id].v > 0)? true : false ): false);
  }
  
  bool exists(edge *e) {
	  return ((e != NULL)? ((e->v > 0)? true : false ): false);
  }
  
  edge* next_edge() {
	  while ((!exists_e(i_idE)) && (i_idE < edgeindex)) {
		  i_idE++;
	  }
	  return (exists_e(i_idE)? &E[i_idE++] : NULL );
  }
  
  inline void vertex_iterator_start() {
     i_idV = 0;
  }
  
  vertex* next_vertex() {
    while ((!exists(i_idV)) && (i_idV <= MAXID()))
      i_idV++;
    if (i_idV > MAXID())
      return NULL;
    return &V[i_idV++];
  }
  
  inline edge* getedge(int32_t id) {
	  return (exists(&E[id])? &E[id] : NULL);
  }
    
 
  vertex* getneighbor(vertex *u, int32_t k) {
    if (u != NULL) {
		if (!exists(u->edges[k])) return NULL;
		return &V[(u->edges[k])->v];
    }
    return NULL;
  }
  
  edge* getedge(vertex *u, int32_t k) {
    if (u != NULL) {
		if (k >= u->deg) return NULL;
		if (!exists(u->edges[k])) return NULL;
		return u->edges[k];
    }
    return NULL;
  }
  
  vertex* getrandomneighbor(vertex *u) {
    int32_t i;
    if (u != NULL) {
      if (u->deg == 0) return u;
      i = myrand(u->deg);
	  if (!exists(u->edges[i])) return NULL;
	  return &V[(u->edges[i])->v];
    }
    return NULL;
  }
  
  edge* randomedge() {
	  int32_t r;
	  
	  do {
		  r = myrand(edgeindex);
	  } while (!exists(&E[r]));
	  return &E[r];
  }
  
  edge* randomedge(vertex *u) {
	  edge *e;
	  if (u != NULL) {
		  if (u->deg > 0) {
			  do {
				  e = u->edges[myrand(u->deg)];
			  } while (!exists(e));
			  return e;
		  }
	  }
	  return NULL;
  }
    
  vertex* randomvertex() {
    int u = (myrand(_MAXID+1));
    while (!exists(u)) 
      u = (myrand(_MAXID+1));
    return &V[u];
  }
  
  
  inline int32_t indegree(vertex *u) {
	  return ((u != NULL)? (u->indeg) : (-1));
  }
  
  inline int32_t outdegree(vertex *u) {
	  return ((u != NULL)? (u->outdeg) : (-1));
  }
  
  inline int32_t degree(vertex *u) {
	  return ((u != NULL)? (u->deg) : (-1));
  }
  
  inline int32_t degree(int32_t u) {
	  return degree(getvertex(u));
  }
  
  inline int32_t indegree(int32_t u) {
	  return indegree(getvertex(u));
  }
  
  inline int32_t outdegree(int32_t u) {
	  return outdegree(getvertex(u));
  }
  
  inline int32_t MAXID() {
    return _MAXID;
  }

  inline int32_t size() {
    return N;
  }

  inline int32_t no_edges() {
    return noedges;
  }

  inline bool exists(int32_t n) {
    return ((n <= MAXID())? (V[n].edges != NULL) : false);
  }
  
  inline bool exists(vertex *v) {
	  return (v != NULL);
  }
  
  edge * reverseEdge(edge *e) {
	  vertex *v;
	  int32_t k;
	  
	  if (exists(e)) {
		  v = getvertex(e->v);
		  if (exists(v)) {
			  for (k =0; k < v->deg; k++) {
				  if (v->edges[k]->v == e->u) 
					  return v->edges[k];
			  }
		  }
	  }
	  return NULL;
  }
  
  void addedge(int32_t u, int32_t v, _PTYPE p, bool trueedge) {
    vertex *up;
    int32_t k;
    int64_t eID;

    
    if (edgeindex >= reservedspaceE) {
      cerr << "Fatal Error: More edges than previously allocated = " << reservedspaceE << endl;
      abort();
    }
	
    // see if edge is repeated
    up = getvertex(u);
    if (up != NULL) {
      for (k=0; k < up->deg; k++) {
        if (up->edges[k] != NULL) {
		  	//cerr << "q " << up->edges[k] << "  deg = "<<up->deg<<endl;
          	if (up->edges[k]->v == v) {
				// repeated edge... update and get out
				if (trueedge) {
				V[u].outdeg++;
				}
				if (trueedge) V[v].indeg++;
				if (trueedge) (up->edges[k])->p = p;
				return;
          }
        }
      }
    }


	eID = u>v?u:v;
	eID = eID<<32;
	eID += u<v?u:v;
    edge_set.insert(eID);

    
    E[edgeindex].u = u;
    E[edgeindex].v = v;
    E[edgeindex].p = p;
	if (trueedge) updatevertex(u);
	if (trueedge) updatevertex(v);
	if (V[u].deg >= V[u].neigsize) {
		cerr << "Error: Dynamic edge allocation full. Cannot allocate more dynamic edges for vertex "<<u<<"; it already has "<<V[u].deg<<" edges (its maximum)"<<endl;
		exit(0);
	}
	V[u].edges[V[u].deg] = &E[edgeindex];
	V[u].deg++;
	if (trueedge){
		V[u].outdeg++;
	} 
	if (trueedge) V[v].indeg++;
	if (trueedge) V[u].flag = 0;
	if (trueedge) V[v].flag = 0;
	edgeindex++;
	noedges++;
  }

  inline bool existedge(vertex *u, vertex *v){
  	  int32_t i,j;
	  i = u->id;
	  j = v->id;
	  int64_t eID = i>j?i:j;
	  eID = eID<<32;
	  eID += i<j?i:j;
	  return (edge_set.find(eID) != edge_set.end())?true : false;
  }

	inline int32_t motif4_ID(vertex *v, vertex *u, vertex *w, vertex *r){
		int32_t i, j;
		unsigned int x;
		vertex *V[4];
		
		V[0] = v;
		V[1] = u;
		V[2] = w;
		V[3] = r;

		x = 0;
		for(i=0; i<4; i++){
			for(j=i+1; j<4; j++){
				x <<= 1;
				if(V[i]==V[j]) cerr<<"error"<<endl;
				if(existedge(V[i],V[j])){
					x = x + 1;
				}			 
			}	
		}

	    if(matrix_to_motif4class.find(x)==matrix_to_motif4class.end()){
			for(i=0; i<4; i++){
				cerr<<V[i]->id<<endl;
			}
			for(i=0; i<4; i++){
				for(j=i+1; j<4; j++){
					cerr<<existedge(V[i],V[j]);			 
				}
				cerr<<endl;	
			}		
	    }
	  	return matrix_to_motif4class[x];
	  }
  
};
  
class Graph : public Gdb {

  private:

    void read_file(const char *file)
    {
		FILE *f;
		int32_t i,j;
        int32_t maxid = 0;
        int32_t p_reservedspaceE;
		char st[1000];
		
        p_reservedspaceE = 0;
		sprintf(st,"zcat %s",file);
		f = popen(st,"r");
		if (f == NULL) {
			cerr << "# Error opening file "<<file<<endl;
			exit(1);
		}
		while (!feof(f)) {
		  if (fscanf(f,"%d\t%d\n",&i,&j) == 2){
			  if (i != j) {
				  maxid = MAX(MAX(maxid,i+1),j+1);
				  p_reservedspaceE+=2;
			  }
		  }
		}
        pclose(f);
		if (maxid == 0) {
			cerr << "# Error with graph file "<<file<<endl;
			exit(1);
		}
        init(p_reservedspaceE,maxid+1);
        f = popen(st,"r");
        while (!feof(f)) {
          if (fscanf(f,"%d\t%d\n",&i,&j) == 2){
			  if (i != j) {
//				cerr << "edge ("<<i<<","<<j<<")"<<endl;
				addedge(i+1,j+1,DIRECTED_GRAPH_EDGE_FLAG,true);
				// creates edge j->i (because the graph is directed! and we need an undirected graph)
				addedge(j+1,i+1,INVALID_EDGE_FLAG,false);				
			  }
          }
        }
        pclose(f);
 	}
 
  public: 
	
	Graph(const char *filename) 
    :Gdb()
    { 
	  read_file(filename);
	}
	
	~Graph() {
	}
    
};



class Path3 {
	private:
		Graph *G;
		int64_t gammar;
		int64_t * gammar_array;
		int64_t Lamda;
		edge ** edge_array;
		int32_t size_gammar_array;
		int64_t m[6];

		
	public:
		Path3(Graph *pG) {
			for(int i=0; i<6; i++){
				m[i] = 0;
			}
			G = pG;
			gammar_array = (int64_t *) zalloc(G->no_edges()* sizeof(int64_t));
			edge_array = (edge**) zalloc(G->no_edges()* sizeof(edge*));
		}
		~Path3(){
				free(gammar_array);
				free(edge_array);
		}

		int64_t * get_m(){
			return m;
		}


		int64_t get_Lamda(){
			return Lamda;
		}

		int64_t get_gammar(){
			return gammar;
		}
		
		void compute_weights() {
					
		  	vertex *u, *v;
			edge * e;
			int64_t gammar_e, acc_gammar_e, d;
			
			acc_gammar_e = 0;
			size_gammar_array = 0;

		
			G->edge_iterator_start();
			while ((e = G->next_edge()) != NULL) 
			{
				u = G->getvertex(e->u);
				v = G->getvertex(e->v);		
				gammar_e = (u->deg - 1);
				gammar_e = gammar_e * (v->deg - 1);
				
				
				if(gammar_e == 0) continue;
				acc_gammar_e += gammar_e ;
				gammar_array[size_gammar_array] = acc_gammar_e;
				edge_array[size_gammar_array] = e;
				size_gammar_array++;
			}
			gammar = acc_gammar_e/2;

			Lamda = 0;
			G->vertex_iterator_start();
			while ((u = G->next_vertex()) != NULL) 
			{
				d = u->deg;	
				Lamda += d * (d - 1) * (d - 2)/6;
			}
			
		}

		void sampling(int64_t batchsize){
			int64_t rnd_weight;
			int32_t i, j, B4;
			vertex *v, *u, *w, *r;
			edge *e;
			
			for(B4=0; B4<batchsize; B4++)
			{
			 	rnd_weight = myrand<int64_t>(2*gammar) + 1;
			 	i = bineary_search(gammar_array, size_gammar_array, rnd_weight);

				e = edge_array[i];
				v = G->getvertex(e->v);
				u = G->getvertex(e->u);
				
				do{
					w = G->getrandomneighbor(v);
				}while(w==u);
				
				do{
					r = G->getrandomneighbor(u);
				}while(r==v);
							
				if(r==w) continue;

				j = G->motif4_ID(v,u,w,r) - 1;
				m[j]++;	
			}
		}
};




class CenteredPath3 {
	private:
		Graph *G;
		int64_t gammar;
		int64_t * gammar_array;
		edge ** edge_array;
		int32_t size_gammar_array;
		int64_t m[6];
		
	public:
		CenteredPath3(Graph *pG) {
			int32_t i;
			G = pG;
			gammar_array = (int64_t *) zalloc(G->no_edges()* sizeof(int64_t));
			edge_array = (edge**) zalloc(G->no_edges()* sizeof(edge*));
			for(i=0; i<6; i++){
				m[i] = 0;
			}
		}
		~CenteredPath3(){
				free(gammar_array);
				free(edge_array);
		}

		int64_t * get_m(){
			return m;
		}

		int64_t get_gammar(){
			return gammar;
		}


		bool vertexorder(vertex *u, vertex *v){
			if (u->deg > v->deg) return 1;
			if (u->deg == v->deg && u->id > v->id) return 1;
			return 0;
		}
		
		void compute_weights() {
					
		  	vertex *u, *v, *w;
			edge * e;
			int64_t gammar_e, acc_gammar_e, i, d, duv, dvu;
			
			acc_gammar_e = 0;
			size_gammar_array = 0;

		
			G->edge_iterator_start();
			while ((e = G->next_edge()) != NULL) 
			{
				u = G->getvertex(e->u);
				v = G->getvertex(e->v);

				duv = 0;
				dvu = 0;
				d = u->deg;
				for(i=0; i<d; i++){
					w = G->getneighbor(u, i);
					if(vertexorder(w,v)){
						duv++;
					}
				}

				d = v->deg;
				for(i=0; i<d; i++){
					w = G->getneighbor(v, i);
					if(vertexorder(w,u)){
						dvu++;
					}
				}
				e->neighbor_u_v = (int32_t*) zalloc(duv*sizeof(int32_t));
				e->neighbor_v_u = (int32_t*) zalloc(dvu*sizeof(int32_t));

				duv = 0;
				d = u->deg;
				for(i=0; i<d; i++){
					w = G->getneighbor(u, i);
					if(vertexorder(w,v)){
						e->neighbor_u_v[duv] = w->id;
						duv++;
					}
				}

				dvu = 0;
				d = v->deg;
				for(i=0; i<d; i++){
					w = G->getneighbor(v, i);
					if(vertexorder(w,u)){
						e->neighbor_v_u[dvu] = w->id;
						dvu++;
					}
				}
				e->duv = duv;
				e->dvu = dvu;
				gammar_e = duv * dvu;
							
				if(gammar_e == 0) continue;
				acc_gammar_e += gammar_e ;
				gammar_array[size_gammar_array] = acc_gammar_e;
				edge_array[size_gammar_array] = e;
				size_gammar_array++;
				
			}
			gammar = acc_gammar_e/2;		
		}

		void sampling(int64_t batchsize){
			int64_t rnd_weight;
			int32_t i, j, B4;
			vertex *v, *u, *w, *r;
			edge *e;

			for(B4=0; B4<batchsize; B4++)
			{
			 	rnd_weight = myrand<int64_t>(2*gammar) + 1;
			 	i = bineary_search(gammar_array, size_gammar_array, rnd_weight);
				//cerr<<"i:"<<i<<'\t'<<size_gammar_array<<endl;
				e = edge_array[i];
				v = G->getvertex(e->v);
				u = G->getvertex(e->u);

				rnd_weight = myrand<int32_t>(e->duv);
				w=G->getvertex(e->neighbor_u_v[rnd_weight]);

				rnd_weight = myrand<int32_t>(e->dvu);
				r=G->getvertex(e->neighbor_v_u[rnd_weight]);
							
				if(r==w) continue;
				if(!G->existedge(r,w)) continue;

				j = G->motif4_ID(v,u,w,r) - 1;
				m[j]++;				
			}
		}
};

class MOSS4 {
	private:
		Graph *G;
		int64_t B4;
		int64_t Lamda1;
		int64_t gammar1;
		int64_t gammar2;
		int64_t Bmax;
		double StdErrMax;
		int32_t phi1[6];
		int64_t *m1;
		int64_t *m2;

		
	public:
		MOSS4(Graph *pG, int64_t  bmax, double stdErrMax) {
			G = pG;
			int32_t phi1_value[6]={1,0,4,2,6,12};
			for(int i=0; i<6; i++){
				phi1[i] = phi1_value[i];
			}
			Bmax = bmax;
			StdErrMax = stdErrMax;
		}
		~MOSS4(){
		}
		void sampling(){

			int32_t i, B4;
			double p1[6];
			double n1[6], var1[6];
			double p2[6];
			double n2[6], var2[6];
			double n[6], var[6], lamda1[6], lamda2[6];
			
			int64_t batchsize = 1000;
			int64_t checkB4 = 0;
			
			Path3 *path3;
			CenteredPath3 *centeredPath3;
			
			path3 = new Path3(G);
			path3->compute_weights();
			m1 = path3->get_m();
			Lamda1 = path3->get_Lamda();
			gammar1 = path3->get_gammar();

			B4 = 0;			
			do{
				path3->sampling(batchsize);
				B4 += batchsize;

				for(i=0; i<6; i++){
					if (i == 1) continue;
					p1[i] = phi1[i];
					p1[i] = p1[i]/gammar1; 
					n1[i] = m1[i]/(B4*p1[i]);
					var1[i] = n1[i] * (1/p1[i]-n1[i])/B4;
				}
				
				n1[1] =	Lamda1 - n1[3] - 2 * n1[4] - 4 * n1[5];
				var1[1] = (n1[3]/p1[3] + 4 * n1[4]/p1[4] + 16 * n1[5]/p1[5] - (n1[3] + 2 * n1[4] + 4 * n1[5]) * (n1[3] + 2 * n1[4] + 4 * n1[5]))/B4;
				if(sqrt(var1[0])/n1[0]<StdErrMax && sqrt(var1[1])/n1[1]<StdErrMax && sqrt(var1[3])/n1[3]<StdErrMax){
					break;
				}
			}while(B4 < Bmax);

			if(B4 < Bmax){
				double est_stdErrMax = 0;
				double stdErr;
				for(i=0; i<6; i++){
					if (n1[i] > 0){
						stdErr = sqrt(var1[i])/n1[i];
						if(est_stdErrMax < stdErr){
							est_stdErrMax = stdErr;
						}
					}
				}
				double Br;
				Br = (est_stdErrMax/StdErrMax)*(est_stdErrMax/StdErrMax) - B4;
				double edge_num;
				edge_num = G->no_edges();
				if(2*(edge_num*edge_num)*log(2)/log(edge_num) < Br){
					centeredPath3 = new CenteredPath3(G);
					centeredPath3->compute_weights();
					gammar2 = centeredPath3->get_gammar();
					if(gammar1/gammar2 > 6){
					    
						m2 = centeredPath3->get_m();
						checkB4=0;

						do{
							centeredPath3->sampling(batchsize);
							
							checkB4 += batchsize;

							n[0] = n1[0];
							n[1] = n1[1];
							n[3] = n1[3];

							var[0] = var1[0];
							var[1] = var1[1];
							var[3] = var1[3];						 
							
							p2[2] = 1.0/gammar2;
							n2[2] = m2[2]/(checkB4*p2[2]);
							var2[2] = n2[2] * (1/p2[2]-n2[2])/checkB4;

							lamda1[2] = var2[2]/(var1[2]+var2[2]);
							lamda2[2] = var1[2]/(var1[2]+var2[2]);
							n[2] = lamda1[2] * n1[2] + lamda2[2] * n2[2];
							var[2] = var1[2]*var2[2]/(var1[2]+var2[2]);


							p2[4] = 1.0/gammar2;
							n2[4] = m2[4]/(checkB4*p2[4]);
							var2[4] = n2[4] * (1/p2[4]-n2[4])/checkB4;


							lamda1[4] = var2[4]/(var1[4]+var2[4]);
							lamda2[4] = var1[4]/(var1[4]+var2[4]);
							n[4] = lamda1[4] * n1[4] + lamda2[4] * n2[4];
							var[4] = var1[4]*var2[4]/(var1[4]+var2[4]);

							p2[5] = 3.0/gammar2;
							n2[5] = m2[5]/(checkB4*p2[5]);
							var2[5] = n2[5] * (1/p2[5]-n2[5])/checkB4;

							lamda1[5] = var2[5]/(var1[5]+var2[5]);
							lamda2[5] = var1[5]/(var1[5]+var2[5]);
							n[5] = lamda1[5] * n1[5] + lamda2[5] * n2[5];
							var[5] = var1[5]*var2[5]/(var1[5]+var2[5]);
							if(sqrt(var[2])/n[2]<StdErrMax && sqrt(var[4])/n[4]<StdErrMax && sqrt(var[5])/n[5]<StdErrMax){
								cerr << "4-node graphlet ID: \t graphlet count \t StdErr" << endl;			
								for(i=0; i<6; i++){
									cerr << i + 1 << '\t' << n[i] << '\t' << sqrt(var[i])/n[i] <<endl;
								}
								if (centeredPath3 != NULL) delete centeredPath3;
								return;
							}					
						}while(B4+checkB4<Bmax);
						cerr << "4-node graphlet ID: \t graphlet count \t StdErr" << endl;			
						for(i=0; i<6; i++){
							cerr << i + 1 << '\t' << n[i] << '\t' << sqrt(var[i])/n[i] <<endl;
						}
						if (centeredPath3 != NULL) delete centeredPath3;
						return;
					}					
				}
				else{
					do{
						path3->sampling(batchsize);
						B4 += batchsize;
					
						for(i=0; i<6; i++){
							if (i == 1) continue;
							p1[i] = phi1[i];
							p1[i] = p1[i]/gammar1; 
							n1[i] = m1[i]/(B4*p1[i]);
							var1[i] = n1[i] * (1/p1[i]-n1[i])/B4;
						}
						
						n1[1] = Lamda1 - n1[3] - 2 * n1[4] - 4 * n1[5];
						var1[1] = (n1[3]/p1[3] + 4 * n1[4]/p1[4] + 16 * n1[5]/p1[5] - (n1[3] + 2 * n1[4] + 4 * n1[5]) * (n1[3] + 2 * n1[4] + 4 * n1[5]))/B4;
						if(sqrt(var1[2])/n1[2]<StdErrMax && sqrt(var1[4])/n1[4]<StdErrMax && sqrt(var1[5])/n1[5]<StdErrMax){
							cerr << "4-node graphlet ID: \t graphlet count \t StdErr" << endl;			
							for(i=0; i<6; i++){
								cerr << i + 1 << '\t' << n1[i] << '\t' << sqrt(var1[i])/n1[i] <<endl;
							}
							return;
						}
					}while(B4 < Bmax);

					cerr << "4-node graphlet ID: \t graphlet count \t StdErr" << endl;			
					for(i=0; i<6; i++){
						cerr << i + 1 << '\t' << n1[i] << '\t' << sqrt(var1[i])/n1[i] <<endl;
					}
					return;

				}

			}
			cerr << "4-node graphlet ID: \t graphlet count \t StdErr" << endl;			
			for(i=0; i<6; i++){
				cerr << i + 1 << '\t' << n1[i] << '\t' << sqrt(var1[i])/n1[i] <<endl;
			}

			if (path3 != NULL) delete path3;

		}


};


int main(int argc, char *argv[]) {
	Graph *G;
	MOSS4 *moss4;
	int32_t Bmax;
	char *filename;
	double StdErrMax;
	
	if (argc != 4) {
		cerr << "Missing parameters:\n" <<
		"   <filename>: trace file name\n" <<
		"   <B4max>: maximum sampling budget of MOSS4\n" <<
		"   <StdErrMax>: desired StdErr of NOSS4\n" << endl;	
		exit(1);
	}
	filename = argv[1];
	Bmax = atoi(argv[2]);
	StdErrMax = atof(argv[3]);
	
	cerr.precision(15);
	cerr.setf(ios::scientific,ios::floatfield);
	
	cerr << "#Reading the graph file on disk and building its adjacent list in memory...\n";
	clock_t start_t = clock();
	G = new Graph(filename);
	clock_t end_t = clock();
	cerr << "#Finished reading the graph file on disk and building its adjacent list in memory...\n";
	cerr << "#Number of edges = " << G->no_edges() << endl;
	cerr << "#Number of vertices = " << G->size() << endl;
	cerr << "Time of reading the graph file on disk and building its adjacent list in memory = "<<(float)(end_t-start_t)/CLOCKS_PER_SEC << " seconds" <<endl;
	

	cerr << "Starting sampling 4-node CISes..." << endl;
	moss4 = new MOSS4(G, Bmax, StdErrMax);
	start_t = clock();
	moss4->sampling();
	

	end_t = clock();
    cerr << "Time of sampling and estimating motif frequencies = " << (float)(end_t-start_t)/CLOCKS_PER_SEC << " seconds" << endl;

	if (moss4 != NULL) delete moss4;	

	
	delete G;
	return 0;
}

