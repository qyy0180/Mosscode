#include <iostream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <inttypes.h>
#include <limits.h>
#include <cmath>
#include <queue>
#include <stack>
#include <stdio.h>
#include <ext/hash_map>
#include <ext/hash_set>
#include "RandomLib/Random.hpp"

#define _FLOAT long double
#define _PTYPE float
#define _FLAGTYPE uint8_t

#define DIRECTED_GRAPH_EDGE_FLAG 0
#define INVALID_EDGE_FLAG -1

//largest positive value an int32_t can hold.
#define INT32_MAX 0x7fffffffL

//largest negative value an int32_t can hold.
#define INT32_MIN (-INT32_MAX - 1L) 

int32_t directedGFlag=0;
int32_t independence_cost = 1;
int32_t maxOutdegree = 0;

using namespace __gnu_cxx; 
using namespace std;
RandomLib::Random rnd;		// r created with random seed

template <typename data_type>
inline data_type myrand(data_type max) {
	return rnd.IntegerC<data_type>(0,max-1);
}

inline double myUnifrand() {
	// r.Fixed() is in the interval (0, 1)
	return rnd.Fixed();
}

inline int32_t bineary_search(int64_t * weights, int32_t len, int64_t search_value) {
	int32_t i;
	int32_t head, tail, mid;

	i=0;

	while(weights[i]==0){
		i++;
	}
	head = i;
	
	if(search_value<=weights[head]){
		return head;
	}
	head = 0;
	tail = len - 1;
	while(tail - head > 1){
		mid = (head + tail)/2;
		if (search_value == weights[mid]){
			break;
		}
		if (search_value < weights[mid]){
			tail = mid;
		}
		else{
			head = mid+1;
		}
	}
	if(tail == head){
		return head;
	}
	if(tail - head == 1){
		if (search_value<=weights[head]){
			return head;
		}
		else{
			return tail;
		}
	}
	while(weights[mid] == search_value){
		mid--;
	}
	return mid+1;
}



#define MIN(a,b) ((a)>(b)?(b):(a))
#define MAX(a,b) ((a)<(b)?(b):(a))
#define ABSMAX(a,b) (abs(a)<abs(b)?(b):(a))



struct edge {
  int32_t u,v;
  _PTYPE p;
};

struct vertex {
	_FLAGTYPE flag;
	int32_t  deg, undirected_deg;
	int32_t  indeg, outdeg;
	int32_t  neigsize;
    int32_t id;
	int64_t* neighbor_weights;
	int64_t* neighbor_weights_u;
	edge** edges;
};

void *zrealloc(void *ptr, size_t newsize, size_t oldsize) {
  int8_t *p = (int8_t *) realloc(ptr,newsize);
  if (p == NULL) {
      cerr << "Could not allocate "<<((_FLOAT)(newsize))/(1024*1024)<<"Kbytes. Aborting."<<endl;
      abort();
  }
  memset(p+oldsize,0,newsize - oldsize);
  return (void*)p;
}

void *zalloc(size_t newsize) {
  int8_t *p = (int8_t *) malloc(newsize);
  if (p == NULL) {
      cerr << "Could not allocate "<<((_FLOAT)(newsize))/(1024*1024)<<"Kbytes. Aborting."<<endl;
      abort();
  }
  memset(p,0,newsize);
  return (void*)p;
}

class Gdb {
private:
  int32_t reservedspaceE;
  int32_t reservedspaceV;
  int32_t edgeindex;
  int32_t N;
  int32_t _MAXID;
  int32_t noedges;
  int32_t i_idE, i_idV;
  
  vertex *V;
  edge *E;

  hash_set<int64_t> edge_set;
  hash_map<int,int> matrix_to_motif5class;
  
public:
  Gdb() {
  }
  ~Gdb(){
  	vertex *v;
	vertex_iterator_start();
	while ((v = next_vertex()) != NULL) 
	{  	
	  	free(v->edges);
		free(v->neighbor_weights);
		free(v->neighbor_weights_u);
	}
  	free(V);
	free(E);
  }

   void set_matrix_to_motif5class(){
 	    FILE *fp;
 	    int i,j;
 	    fp = fopen("matrix_motif5","r");
 	    while(!feof(fp)){
 	       if(fscanf(fp,"%d\t%d\n",&i,&j) == 2){
                matrix_to_motif5class[i] = j;
 	       }
 	    }
	    fclose(fp);
  }

  void init(int32_t p_reservedspaceE, int32_t p_reservedspaceV) {
    edgeindex = 0;
    N = 0;
    _MAXID = 0;
	noedges = 0;
    reservedspaceE = p_reservedspaceE;
    reservedspaceV = p_reservedspaceV;
    E = (edge *) zalloc(reservedspaceE * sizeof(edge));
    V = (vertex *) zalloc(reservedspaceV * sizeof(vertex));
	set_matrix_to_motif5class();
  }


    void updatevertex(int32_t u) {
    if (u >= reservedspaceV) {
      cerr << "Fatal Error: More vertices than previously allocated = "<<reservedspaceV<<endl;
      abort();
    }
    _MAXID = MAX(_MAXID,u);
    if (V[u].edges == NULL) {
      N++;
      V[u].neigsize = 4;
      V[u].edges = (edge**) zalloc(V[u].neigsize*sizeof(edge*));
	  V[u].neighbor_weights = (int64_t*) zalloc(V[u].neigsize*sizeof(int64_t));
	  V[u].neighbor_weights_u = (int64_t*) zalloc(V[u].neigsize*sizeof(int64_t));

    }
    if (V[u].deg >= V[u].neigsize) {
	  V[u].edges = (edge**) zrealloc(V[u].edges, (V[u].neigsize*2)*sizeof(edge*), V[u].neigsize*sizeof(edge*));
	  V[u].neighbor_weights = (int64_t*) zrealloc(V[u].neighbor_weights, (V[u].neigsize*2)*sizeof(int64_t), V[u].neigsize*sizeof(int64_t));
	  V[u].neighbor_weights_u = (int64_t*) zrealloc(V[u].neighbor_weights_u, (V[u].neigsize*2)*sizeof(int64_t), V[u].neigsize*sizeof(int64_t));
	  V[u].neigsize *= 2;
    }
    V[u].id = u;
  }
  inline vertex* getvertex(int32_t u) {
    return (exists(u))? &V[u] : NULL;
  }
  
  inline void edge_iterator_start() {
    i_idE = 0;
  }
  
  inline bool exists_e(int32_t id) {
	  return ((id < edgeindex)? ((E[id].v > 0)? true : false ): false);
  }
  
  bool exists(edge *e) {
	  return ((e != NULL)? ((e->v > 0)? true : false ): false);
  }
  
  edge* next_edge() {
	  while ((!exists_e(i_idE)) && (i_idE < edgeindex)) {
		  i_idE++;
	  }
	  return (exists_e(i_idE)? &E[i_idE++] : NULL );
  }
  
  inline void vertex_iterator_start() {
     i_idV = 0;
  }
  
  vertex* next_vertex() {
    while ((!exists(i_idV)) && (i_idV <= MAXID()))
      i_idV++;
    if (i_idV > MAXID())
      return NULL;
    return &V[i_idV++];
  }
  
  inline edge* getedge(int32_t id) {
	  return (exists(&E[id])? &E[id] : NULL);
  }
    
 
  vertex* getneighbor(vertex *u, int32_t k) {
    if (u != NULL) {
		if (!exists(u->edges[k])) return NULL;
		return &V[(u->edges[k])->v];
    }
    return NULL;
  }
  
  edge* getedge(vertex *u, int32_t k) {
    if (u != NULL) {
		if (k >= u->deg) return NULL;
		if (!exists(u->edges[k])) return NULL;
		return u->edges[k];
    }
    return NULL;
  }
  
  vertex* getrandomneighbor(vertex *u) {
    int32_t i;
    if (u != NULL) {
      if (u->deg == 0) return u;
      i = myrand(u->deg);
	  if (!exists(u->edges[i])) return NULL;
	  return &V[(u->edges[i])->v];
    }
    return NULL;
  }
  
  edge* randomedge() {
	  int32_t r;
	  
	  do {
		  r = myrand(edgeindex);
	  } while (!exists(&E[r]));
	  return &E[r];
  }
  
  edge* randomedge(vertex *u) {
	  edge *e;
	  if (u != NULL) {
		  if (u->deg > 0) {
			  do {
				  e = u->edges[myrand(u->deg)];
			  } while (!exists(e));
			  return e;
		  }
	  }
	  return NULL;
  }
    
  vertex* randomvertex() {
    int u = (myrand(_MAXID+1));
    while (!exists(u)) 
      u = (myrand(_MAXID+1));
    return &V[u];
  }
  
  
  inline int32_t indegree(vertex *u) {
	  return ((u != NULL)? (u->indeg) : (-1));
  }
  
  inline int32_t outdegree(vertex *u) {
	  return ((u != NULL)? (u->outdeg) : (-1));
  }
  
  inline int32_t degree(vertex *u) {
	  return ((u != NULL)? (u->deg) : (-1));
  }
  
  inline int32_t degree(int32_t u) {
	  return degree(getvertex(u));
  }
  
  inline int32_t indegree(int32_t u) {
	  return indegree(getvertex(u));
  }
  
  inline int32_t outdegree(int32_t u) {
	  return outdegree(getvertex(u));
  }
  
  inline int32_t MAXID() {
    return _MAXID;
  }

  inline int32_t size() {
    return N;
  }

  inline int32_t no_edges() {
    return noedges;
  }

  inline bool exists(int32_t n) {
    return ((n <= MAXID())? (V[n].edges != NULL) : false);
  }
  
  inline bool exists(vertex *v) {
	  return (v != NULL);
  }
  
  edge * reverseEdge(edge *e) {
	  vertex *v;
	  int32_t k;
	  
	  if (exists(e)) {
		  v = getvertex(e->v);
		  if (exists(v)) {
			  for (k =0; k < v->deg; k++) {
				  if (v->edges[k]->v == e->u) 
					  return v->edges[k];
			  }
		  }
	  }
	  return NULL;
  }
  
  void addedge(int32_t u, int32_t v, _PTYPE p, bool trueedge) {
    vertex *up;
    int32_t k;
    int64_t eID;

    
    if (edgeindex >= reservedspaceE) {
      cerr << "Fatal Error: More edges than previously allocated = " << reservedspaceE << endl;
      abort();
    }
	
    // see if edge is repeated
    up = getvertex(u);
    if (up != NULL) {
      for (k=0; k < up->deg; k++) {
        if (up->edges[k] != NULL) {
		  	//cerr << "q " << up->edges[k] << "  deg = "<<up->deg<<endl;
          	if (up->edges[k]->v == v) {
				// repeated edge... update and get out
				if (trueedge) {
				V[u].outdeg++;
				}
				if (trueedge) V[v].indeg++;
				if (trueedge) (up->edges[k])->p = p;
				return;
          }
        }
      }
    }


	eID = u>v?u:v;
	eID = eID<<32;
	eID += u<v?u:v;
    edge_set.insert(eID);

    
    E[edgeindex].u = u;
    E[edgeindex].v = v;
    E[edgeindex].p = p;
	if (trueedge) updatevertex(u);
	if (trueedge) updatevertex(v);
	if (V[u].deg >= V[u].neigsize) {
		cerr << "Error: Dynamic edge allocation full. Cannot allocate more dynamic edges for vertex "<<u<<"; it already has "<<V[u].deg<<" edges (its maximum)"<<endl;
		exit(0);
	}
	V[u].edges[V[u].deg] = &E[edgeindex];
	V[u].deg++;
	if (trueedge){
		V[u].outdeg++;
	} 
	if (trueedge) V[v].indeg++;
	if (trueedge) V[u].flag = 0;
	if (trueedge) V[v].flag = 0;
	edgeindex++;
	noedges++;
  }

  inline bool existedge(vertex *u, vertex *v){
  	  int32_t i,j;
	  i = u->id;
	  j = v->id;
	  int64_t eID = i>j?i:j;
	  eID = eID<<32;
	  eID += i<j?i:j;
	  return (edge_set.find(eID) != edge_set.end())?true : false;
  }
  inline int32_t motif5_ID(vertex *v, vertex *u, vertex *w, vertex *r, vertex *t){
	int32_t i, j;
	unsigned int x;
	vertex *V[5];
	
	V[0] = v;
	V[1] = u;
	V[2] = w;
	V[3] = r;
	V[4] = t;

	x = 0;
	for(i=0; i<5; i++){
		for(j=i+1; j<5; j++){
			x <<= 1;
			if(V[i]==V[j]) cerr<<"error"<<endl;
			if(existedge(V[i],V[j])){
				x = x + 1;
			}			 
		}	
	}

    if(matrix_to_motif5class.find(x)==matrix_to_motif5class.end()){
		for(i=0; i<5; i++){
			cerr<<V[i]->id<<endl;
		}
		for(i=0; i<5; i++){
			for(j=i+1; j<5; j++){
				cerr<<existedge(V[i],V[j]);			 
			}
			cerr<<endl;	
		}		
    }
  	return matrix_to_motif5class[x];
  }
};
  
class Graph : public Gdb {

  private:

    void read_file(const char *file)
    {
		FILE *f;
		int32_t i,j;
        int32_t maxid = 0;
        int32_t p_reservedspaceE;
		char st[1000];
		
        p_reservedspaceE = 0;
		sprintf(st,"zcat %s",file);
		f = popen(st,"r");
		if (f == NULL) {
			cerr << "# Error opening file "<<file<<endl;
			exit(1);
		}
		while (!feof(f)) {
		  if (fscanf(f,"%d\t%d\n",&i,&j) == 2){
			  if (i != j) {
				  maxid = MAX(MAX(maxid,i+1),j+1);
				  p_reservedspaceE+=2;
			  }
		  }
		}
        pclose(f);
		if (maxid == 0) {
			cerr << "# Error with graph file "<<file<<endl;
			exit(1);
		}
        init(p_reservedspaceE,maxid+1);
        f = popen(st,"r");
        while (!feof(f)) {
          if (fscanf(f,"%d\t%d\n",&i,&j) == 2){
			  if (i != j) {
//				cerr << "edge ("<<i<<","<<j<<")"<<endl;
				addedge(i+1,j+1,DIRECTED_GRAPH_EDGE_FLAG,true);
				// creates edge j->i (because the graph is directed! and we need an undirected graph)
				addedge(j+1,i+1,INVALID_EDGE_FLAG,false);				
			  }
          }
        }
        pclose(f);
 	}
 
  public: 
	
	Graph(const char *filename) 
    :Gdb()
    { 
	  read_file(filename);
	}
	
	~Graph() {
	}
    
};

class T5 {
	private:
		Graph *G;
		int64_t K1;
		int64_t gammar1;
		double gammar1_float;
		int64_t m[21];
		int64_t *gammar1_array;
		int32_t *vertex_ids;
		int32_t size_gammar1_array;
		int32_t phi1[21];
		double eta[21];
		double var[21];
		
	public:
		T5(Graph *pG) {
			int32_t phi1_value[21]={0,0,1,1,2,0,2,2,4,4,5,4,6,10,9,12,10,20,20,36,60};
			for(int i=0; i<21; i++){
				phi1[i] = phi1_value[i];
				m[i] = 0;
			}
			G = pG;
			K1 = 0;
			gammar1_array = (int64_t *) zalloc(G->size()* sizeof(int64_t));
			vertex_ids = (int32_t *) zalloc(G->size()* sizeof(int32_t));
		}
		~T5(){
				free(gammar1_array);
				free(vertex_ids);
		}

		double * get_eta(){
			return eta;
		}

		double * get_var(){
			return var;
		}
		
		void compute_weights() {
					
		  	vertex *u, *v;
  			int32_t i;
			int64_t gammar_v, acc_gammar_v, acc_sigma_i;
			int64_t t;
			
			acc_gammar_v = 0;
			size_gammar1_array = 0;

		
			G->vertex_iterator_start();
			while ((v = G->next_vertex()) != NULL) 
			{
				acc_sigma_i = 0;
				for(i=0; i<v->deg; i++)
				{
					u=G->getneighbor(v,i);
					acc_sigma_i += u->deg - 1;
					v->neighbor_weights[i] = acc_sigma_i;
				}
				t = v->deg;
				gammar_v = acc_sigma_i * (t-1) * (t-2);
				
				
				if(gammar_v == 0) continue;
				acc_gammar_v += gammar_v ;
				gammar1_array[size_gammar1_array] = acc_gammar_v;
				vertex_ids[size_gammar1_array] = v->id;
				size_gammar1_array++;
			}
			gammar1 = acc_gammar_v;
		}

		void sampling(int64_t batchsize){
			int64_t rnd_weight;
			int32_t i, j, k;
			vertex *v, *u, *w, *r, *t;

			
			for(k=0; k<batchsize; k++)
			{
			 	rnd_weight = myrand<int64_t>(gammar1) + 1;
			 	i = bineary_search(gammar1_array, size_gammar1_array, rnd_weight);
				v = G->getvertex(vertex_ids[i]);
				
				rnd_weight = myrand<int64_t>(v->neighbor_weights[v->deg-1]) + 1;
				i = bineary_search(v->neighbor_weights, v->deg, rnd_weight);
				u = G->getneighbor(v,i);

				do{
					w = G->getrandomneighbor(v);
				}while(w==u);
				
				do{
					r = G->getrandomneighbor(v);
				}while(r==u||r==w);
				
				do{
					t = G->getrandomneighbor(u);
				}while(t==v);
				
				if(t==w||t==r) continue;

				//j is the motif id

				j = G->motif5_ID(v,u,w,r,t) - 1;
				m[j]++;	
				
			}
			K1 += batchsize;
			for(i=0; i<21; i++){
				eta[i] = 0;
				if(phi1[i]>0){
					eta[i] = gammar1;
					eta[i] = m[i]*(eta[i]/(2*K1*phi1[i]));
					var[i] = eta[i] /K1 * (0.5*gammar1/phi1[i]-eta[i]);
				}
			}
		}
};



class Path5 {
	private:
		Graph *G;
		int64_t K2;
		int64_t gammar2;
		int64_t *gammar2_array;
		int64_t m[21];
		int32_t *vertex_ids;
		int32_t size_gammar2_array;
		int32_t phi2[21];		
		double eta[21];
		double var[21];
		
	public:
		Path5(Graph *pG) {
			int32_t phi2_value[21]={1,0,0,2,2,5,1,0,4,7,2,4,6,10,6,6,14,24,18,36,60};		
			for(int i=0; i<21; i++){
				phi2[i] = phi2_value[i];
				m[i] = 0;
			}

			G = pG;
			K2 = 0;
			gammar2_array = (int64_t *) zalloc(G->size()* sizeof(int64_t));
			vertex_ids = (int32_t *) zalloc(G->size()* sizeof(int32_t));
		}
		~Path5(){
				free(gammar2_array);
				free(vertex_ids);
		}

		double * get_eta(){
			return eta;
		}

		double * get_var(){
			return var;
		}
		
		void compute_weights() {
					
		  	vertex *u, *v;
  			int32_t i;
			int64_t gammar_v, acc_gammar_v, acc_mu_i, acc_tau_i;
			int64_t sum_neighbor_deg;
			int64_t t;
			
			acc_gammar_v = 0;
			size_gammar2_array = 0;

			G->vertex_iterator_start();
			while ((v = G->next_vertex()) != NULL) 
			{
				gammar_v = 0;
				acc_mu_i = 0;
				for(i=0; i<v->deg; i++)
				{
					u=G->getneighbor(v,i);
					acc_mu_i += u->deg - 1;
					v->neighbor_weights[i] = acc_mu_i;
				}
				
				sum_neighbor_deg = acc_mu_i;
				gammar_v = sum_neighbor_deg * sum_neighbor_deg;
				acc_tau_i = 0;
						
				for(i=0; i<v->deg; i++)
				{		
					u=G->getneighbor(v,i);
					t = u->deg - 1;
					gammar_v = gammar_v - t*t;
					acc_tau_i += t*(sum_neighbor_deg - u->deg + 1);
					v->neighbor_weights_u[i] = acc_tau_i;
				}
				
				if(gammar_v == 0) continue;
				acc_gammar_v += gammar_v;
				gammar2_array[size_gammar2_array] = acc_gammar_v;
				vertex_ids[size_gammar2_array] = v->id;
				size_gammar2_array++;
			}
			gammar2 = acc_gammar_v;
		}

		void sampling(int64_t batchsize){
			int64_t rnd_weight;
			int32_t i, j, k;
			vertex *v, *u, *w, *r, *t;
			
			for(k=0; k<batchsize; k++)
			{
			 	rnd_weight = myrand<int64_t>(gammar2) + 1;
			 	i = bineary_search(gammar2_array, size_gammar2_array, rnd_weight);
				v = G->getvertex(vertex_ids[i]);
			
				rnd_weight = myrand<int64_t>(v->neighbor_weights_u[v->deg-1]) + 1;
				i = bineary_search(v->neighbor_weights_u, v->deg, rnd_weight);
				u = G->getneighbor(v,i);
		
				do{
					rnd_weight = myrand<int64_t>(v->neighbor_weights[v->deg-1]) + 1;
					i = bineary_search(v->neighbor_weights, v->deg, rnd_weight);
					w = G->getneighbor(v,i);
				}while(w==u);

				do{
					r = G->getrandomneighbor(u);
				}while(r==v);
		
				do{
					t = G->getrandomneighbor(w);
				}while(t==v);
			
				if(t==r || t==u || r==w) continue;
				//j is the motif id
				j = G->motif5_ID(v,u,w,r,t) - 1;
				m[j] +=1;						
			}
			K2 += batchsize;
			for(i=0; i<21; i++){
				eta[i] = 0;
				if(phi2[i]>0){
					eta[i] = gammar2;
					eta[i] = m[i]*(eta[i]/(2*K2*phi2[i]));
					var[i] = eta[i]/K2 * (0.5*gammar2/phi2[i]-eta[i]);
				}
			}		
		}
};


class MOSS5 {
	private:
		Graph *G;
		double *eta1;
		double *var1;
		int64_t K1;

		double *eta2;
		double *var2;
		int64_t K2;

		int32_t phi1[21];
		int32_t phi2[21];
		int32_t phi3[21];

		double eta[21];
		double var[21];

		double Lambda4;

		int64_t Bmax;
		double StdErrMax;
		
	public:
		MOSS5(Graph *pG, int64_t  bmax, double stdErrMax) {
			int32_t phi1_value[21]={0,0,1,1,2,0,2,2,4,4,5,4,6,10,9,12,10,20,20,36,60};
			int32_t phi2_value[21]={1,0,0,2,2,5,1,0,4,7,2,4,6,10,6,6,14,24,18,36,60};	
			int32_t phi3_value[21]={0,1,0,0,0,0,0,1,0,0,1,1,0,1,1,2,0,1,2,3,5};
			G = pG;
			Bmax = bmax;
			StdErrMax = stdErrMax;
			for(int i=0; i<21; i++){
				phi1[i] = phi1_value[i];
				phi2[i] = phi2_value[i];
				phi3[i] = phi3_value[i];
				eta[i] = 0;
			}			
		}
		~MOSS5(){			
		}
		
		void compute_Lambda4(){
			vertex *v;
			double d;
			Lambda4 = 0;

			G->vertex_iterator_start();
			while ((v = G->next_vertex()) != NULL) 
			{
				d = v->deg;
				Lambda4 += d*(d-1)*(d-2)*(d-3)/24;
			}
		}

		void sampling(){
			T5 *t5;
			Path5 *p5;
			int64_t batchsize = 1000;
			int64_t B5 = 0;
			double maxstderr;
			
			t5 = new T5(G);
			t5->compute_weights();
			eta1 = t5->get_eta();
			var1 = t5->get_var();
			p5 = new Path5(G);
			p5->compute_weights();
			eta2 = p5->get_eta();
			var2 = p5->get_var();

			compute_Lambda4();
			
			do{
				t5->sampling(batchsize);
				p5->sampling(batchsize);
				maxstderr = estimator_variance();
				B5 += 2 * batchsize;
				K1 = B5/2;
				K2 = B5/2;
			}while(maxstderr >= StdErrMax && B5 < Bmax);
			printresults();						
		}
		
		double estimator_variance(){
			int32_t i, j;
			double lambda1[21], lambda2[21];
			double cov;
			double maxstderr = 0;
			double stderr;
			
			eta[1] = Lambda4;

			for(i = 0; i<21; i++){
				if (i==1) continue;
				if(phi1[i] > 0 && phi2[i]>0){
					if(var1[i] + var2[i] == 0){
						lambda1[i] = 1;
						lambda2[i] = 1;
						continue;
					}
					lambda1[i] = var2[i]/(var1[i] + var2[i]);
					lambda2[i] = var1[i]/(var1[i] + var2[i]);
					eta[i] = lambda1[i] * eta1[i] + lambda2[i] * eta2[i];
					var[i] = var1[i] * var2[i]/(var1[i] + var2[i]);
				}
				else{
					if(phi1[i] > 0){
						eta[i] = eta1[i];
						var[i] = var1[i];
					}
					else{
						eta[i] = eta2[i];
						var[i] = var2[i];
					}
				}				
				if(phi3[i]>0){
					eta[1] -= phi3[i]*eta[i];
				}

			}

			var[1] = 0;
			for(i=0; i<21; i++){
				if(i==1||phi3[i]==0) continue;
				var[1] += phi3[i] * phi3[i] * var[i];

				for(j=0; j<21; j++){
					if(j==i) continue;
					cov = 0;
					if(phi1[i]>0&&phi2[i]>0&&phi1[j]>0&&phi2[j]>0){
						cov = -(lambda1[i] * lambda1[j]/K1 + lambda2[i] * lambda2[j] /K2) * eta[i] * eta[j];
					}
					if(phi1[i]>0&&phi2[i]==0&&phi1[j]>0&&phi2[j]>0){
						cov = - lambda1[j] * eta[i] * eta[j]/K1;
					}
					if(phi1[i]>0&&phi2[i]>0&&phi1[j]>0&&phi2[j]==0){
						cov = - lambda1[i] * eta[i] * eta[j]/K1;
					}
					if(phi1[i]>0&&phi2[i]>0&&phi1[j]==0&&phi2[j]>0){
						cov = - lambda2[i] * eta[i] * eta[j]/K2;
					}
					if(phi1[i]==0&&phi2[i]>0&&phi1[j]>0&&phi2[j]>0){
						cov = - lambda2[j] * eta[i] * eta[j]/K2;
					}
					var[1] += cov;
				}
			}		

			for(i=0; i<21; i++){
				if(eta[i] > 0){
					stderr = sqrt(var[i])/eta[i];
					if(maxstderr < stderr) maxstderr = stderr;
				}					
			}
			return maxstderr;
		}


		void printresults(){
			int32_t i;
			cerr<<"5-node graphlet ID"<<'\t'<<"graphlet count"<<'\t'<<"StdErr"<<endl;
			for(i=0; i <21; i++){
				if(eta[i]>0){
					cerr<< i + 1 << '\t' << eta[i] << '\t' << sqrt(var[i])/eta[i] <<endl;
				}
				else{
					cerr<< i + 1 << '\t' << eta[i] << '\t' << "NaN" <<endl;
				}
			}
		}
};


int main(int argc, char *argv[]) {
	Graph *G;
	MOSS5 *moss5;
	int32_t Bmax;
	char *filename;
	double StdErrMax;

	
	if (argc != 4) {		
		cerr << "Missing parameters:\n" <<		
			"   <filename>: trace file name\n" <<		
			"   <B5max>: maximum sampling budget of MOSS5\n" <<		
			"   <StdErrMax>: desired StdErr of NOSS5\n" << endl;
		exit(1);
	}

	filename = argv[1];
	Bmax = atoi(argv[2]);
	StdErrMax = atof(argv[3]);

	cerr.precision(15);
	cerr.setf(ios::scientific,ios::floatfield);
	
	cerr << "#Reading the graph file on disk and building its adjacent list in memory...\n";
	clock_t start_t = clock();
	G = new Graph(filename);
	clock_t end_t = clock();
	cerr << "#Finished reading the graph file on disk and building its adjacent list in memory...\n";
	cerr << "#Number of edges = " << G->no_edges() << endl;
	cerr << "#Number of vertices = " << G->size() << endl;
	cerr <<"Time of reading the graph file on disk and building its adjacent list in memory = "<<(float)(end_t-start_t)/CLOCKS_PER_SEC<<" seconds"<<endl;
	

	cerr << "Starting sampling 5-node CISes..." << endl;
	
	moss5 = new MOSS5(G, Bmax, StdErrMax);
	start_t = clock();
	moss5->sampling();
    
	end_t = clock();
    cerr <<"Time of sampling and estimating motif frequencies = "<<(float)(end_t-start_t)/CLOCKS_PER_SEC<<" seconds"<<endl;

	if (moss5 != NULL) delete moss5;	
	
	delete G;
	return 0;
}

