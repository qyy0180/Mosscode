#include <iostream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <inttypes.h>
#include <limits.h>
#include <cmath>
#include <queue>
#include <stack>
#include <stdio.h>
#include <ext/hash_map>
#include <ext/hash_set>
#include "RandomLib/Random.hpp"

#define _FLOAT long double
#define _PTYPE float
#define _FLAGTYPE uint8_t

#define DIRECTED_GRAPH_EDGE_FLAG 0
#define INVALID_EDGE_FLAG -1

//largest positive value an int32_t can hold.
#define INT32_MAX 0x7fffffffL

//largest negative value an int32_t can hold.
#define INT32_MIN (-INT32_MAX - 1L) 

int32_t directedGFlag=0;
int32_t independence_cost = 1;
int32_t maxOutdegree = 0;

using namespace __gnu_cxx; 
using namespace std;
RandomLib::Random rnd;		// r created with random seed

template <typename data_type>
inline data_type myrand(data_type max) {
	return rnd.IntegerC<data_type>(0,max-1);
}

inline double myUnifrand() {
	// r.Fixed() is in the interval (0, 1)
	return rnd.Fixed();
}

inline int32_t bineary_search(int64_t * weights, int32_t len, int64_t search_value) {
	int32_t i;
	int32_t head, tail, mid;

	i=0;

	while(weights[i]==0){
		i++;
	}
	head = i;
	
	if(search_value<=weights[head]){
		return head;
	}
	head = 0;
	tail = len - 1;
	while(tail - head > 1){
		mid = (head + tail)/2;
		if (search_value == weights[mid]){
			break;
		}
		if (search_value < weights[mid]){
			tail = mid;
		}
		else{
			head = mid+1;
		}
	}
	if(tail == head){
		return head;
	}
	if(tail - head == 1){
		if (search_value<=weights[head]){
			return head;
		}
		else{
			return tail;
		}
	}
	while(weights[mid] == search_value){
		mid--;
	}
	return mid+1;
}



#define MIN(a,b) ((a)>(b)?(b):(a))
#define MAX(a,b) ((a)<(b)?(b):(a))
#define ABSMAX(a,b) (abs(a)<abs(b)?(b):(a))



struct edge {
  int32_t u,v;
  _PTYPE p;
};

struct vertex {
	_FLAGTYPE flag;
	int32_t  deg, undirected_deg;
	int32_t  indeg, outdeg;
	int32_t  neigsize;
    int32_t id;
	int64_t* neighbor_weights;
	int64_t* neighbor_weights_u;
	edge** edges;
};

void *zrealloc(void *ptr, size_t newsize, size_t oldsize) {
  int8_t *p = (int8_t *) realloc(ptr,newsize);
  if (p == NULL) {
      cerr << "Could not allocate "<<((_FLOAT)(newsize))/(1024*1024)<<"Kbytes. Aborting."<<endl;
      abort();
  }
  memset(p+oldsize,0,newsize - oldsize);
  return (void*)p;
}

void *zalloc(size_t newsize) {
  int8_t *p = (int8_t *) malloc(newsize);
  if (p == NULL) {
      cerr << "Could not allocate "<<((_FLOAT)(newsize))/(1024*1024)<<"Kbytes. Aborting."<<endl;
      abort();
  }
  memset(p,0,newsize);
  return (void*)p;
}

class Gdb {
private:
  int32_t reservedspaceE;
  int32_t reservedspaceV;
  int32_t edgeindex;
  int32_t N;
  int32_t _MAXID;
  int32_t noedges;
  int32_t i_idE, i_idV;
  
  vertex *V;
  edge *E;

  hash_set<int64_t> edge_set;
  
public:
  Gdb() {
  }
  ~Gdb(){
  	vertex *v;
	vertex_iterator_start();
	while ((v = next_vertex()) != NULL) 
	{  	
	  	free(v->edges);
		free(v->neighbor_weights);
		free(v->neighbor_weights_u);
	}
  	free(V);
	free(E);
  }



  void init(int32_t p_reservedspaceE, int32_t p_reservedspaceV) {
    edgeindex = 0;
    N = 0;
    _MAXID = 0;
	noedges = 0;
    reservedspaceE = p_reservedspaceE;
    reservedspaceV = p_reservedspaceV;
    E = (edge *) zalloc(reservedspaceE * sizeof(edge));
    V = (vertex *) zalloc(reservedspaceV * sizeof(vertex));
  }


    void updatevertex(int32_t u) {
    if (u >= reservedspaceV) {
      cerr << "Fatal Error: More vertices than previously allocated = "<<reservedspaceV<<endl;
      abort();
    }
    _MAXID = MAX(_MAXID,u);
    if (V[u].edges == NULL) {
      N++;
      V[u].neigsize = 4;
      V[u].edges = (edge**) zalloc(V[u].neigsize*sizeof(edge*));
	  V[u].neighbor_weights = (int64_t*) zalloc(V[u].neigsize*sizeof(int64_t));
	  V[u].neighbor_weights_u = (int64_t*) zalloc(V[u].neigsize*sizeof(int64_t));

    }
    if (V[u].deg >= V[u].neigsize) {
	  V[u].edges = (edge**) zrealloc(V[u].edges, (V[u].neigsize*2)*sizeof(edge*), V[u].neigsize*sizeof(edge*));
	  V[u].neighbor_weights = (int64_t*) zrealloc(V[u].neighbor_weights, (V[u].neigsize*2)*sizeof(int64_t), V[u].neigsize*sizeof(int64_t));
	  V[u].neighbor_weights_u = (int64_t*) zrealloc(V[u].neighbor_weights_u, (V[u].neigsize*2)*sizeof(int64_t), V[u].neigsize*sizeof(int64_t));
	  V[u].neigsize *= 2;
    }
    V[u].id = u;
  }
  inline vertex* getvertex(int32_t u) {
    return (exists(u))? &V[u] : NULL;
  }
  
  inline void edge_iterator_start() {
    i_idE = 0;
  }
  
  inline bool exists_e(int32_t id) {
	  return ((id < edgeindex)? ((E[id].v > 0)? true : false ): false);
  }
  
  bool exists(edge *e) {
	  return ((e != NULL)? ((e->v > 0)? true : false ): false);
  }
  
  edge* next_edge() {
	  while ((!exists_e(i_idE)) && (i_idE < edgeindex)) {
		  i_idE++;
	  }
	  return (exists_e(i_idE)? &E[i_idE++] : NULL );
  }
  
  inline void vertex_iterator_start() {
     i_idV = 0;
  }
  
  vertex* next_vertex() {
    while ((!exists(i_idV)) && (i_idV <= MAXID()))
      i_idV++;
    if (i_idV > MAXID())
      return NULL;
    return &V[i_idV++];
  }
  
  inline edge* getedge(int32_t id) {
	  return (exists(&E[id])? &E[id] : NULL);
  }
    
 
  vertex* getneighbor(vertex *u, int32_t k) {
    if (u != NULL) {
		if (!exists(u->edges[k])) return NULL;
		return &V[(u->edges[k])->v];
    }
    return NULL;
  }
  
  edge* getedge(vertex *u, int32_t k) {
    if (u != NULL) {
		if (k >= u->deg) return NULL;
		if (!exists(u->edges[k])) return NULL;
		return u->edges[k];
    }
    return NULL;
  }
  
  vertex* getrandomneighbor(vertex *u) {
    int32_t i;
    if (u != NULL) {
      if (u->deg == 0) return u;
      i = myrand(u->deg);
	  if (!exists(u->edges[i])) return NULL;
	  return &V[(u->edges[i])->v];
    }
    return NULL;
  }
  
  edge* randomedge() {
	  int32_t r;
	  
	  do {
		  r = myrand(edgeindex);
	  } while (!exists(&E[r]));
	  return &E[r];
  }
  
  edge* randomedge(vertex *u) {
	  edge *e;
	  if (u != NULL) {
		  if (u->deg > 0) {
			  do {
				  e = u->edges[myrand(u->deg)];
			  } while (!exists(e));
			  return e;
		  }
	  }
	  return NULL;
  }
    
  vertex* randomvertex() {
    int u = (myrand(_MAXID+1));
    while (!exists(u)) 
      u = (myrand(_MAXID+1));
    return &V[u];
  }
  
  
  inline int32_t indegree(vertex *u) {
	  return ((u != NULL)? (u->indeg) : (-1));
  }
  
  inline int32_t outdegree(vertex *u) {
	  return ((u != NULL)? (u->outdeg) : (-1));
  }
  
  inline int32_t degree(vertex *u) {
	  return ((u != NULL)? (u->deg) : (-1));
  }
  
  inline int32_t degree(int32_t u) {
	  return degree(getvertex(u));
  }
  
  inline int32_t indegree(int32_t u) {
	  return indegree(getvertex(u));
  }
  
  inline int32_t outdegree(int32_t u) {
	  return outdegree(getvertex(u));
  }
  
  inline int32_t MAXID() {
    return _MAXID;
  }

  inline int32_t size() {
    return N;
  }

  inline int32_t no_edges() {
    return noedges;
  }

  inline bool exists(int32_t n) {
    return ((n <= MAXID())? (V[n].edges != NULL) : false);
  }
  
  inline bool exists(vertex *v) {
	  return (v != NULL);
  }
  
  edge * reverseEdge(edge *e) {
	  vertex *v;
	  int32_t k;
	  
	  if (exists(e)) {
		  v = getvertex(e->v);
		  if (exists(v)) {
			  for (k =0; k < v->deg; k++) {
				  if (v->edges[k]->v == e->u) 
					  return v->edges[k];
			  }
		  }
	  }
	  return NULL;
  }
  
  void addedge(int32_t u, int32_t v, _PTYPE p, bool trueedge) {
    vertex *up;
    int32_t k;
    int64_t eID;

    
    if (edgeindex >= reservedspaceE) {
      cerr << "Fatal Error: More edges than previously allocated = " << reservedspaceE << endl;
      abort();
    }
	
    // see if edge is repeated
    up = getvertex(u);
    if (up != NULL) {
      for (k=0; k < up->deg; k++) {
        if (up->edges[k] != NULL) {
		  	//cerr << "q " << up->edges[k] << "  deg = "<<up->deg<<endl;
          	if (up->edges[k]->v == v) {
				// repeated edge... update and get out
				if (trueedge) {
				V[u].outdeg++;
				}
				if (trueedge) V[v].indeg++;
				if (trueedge) (up->edges[k])->p = p;
				return;
          }
        }
      }
    }


	eID = u>v?u:v;
	eID = eID<<32;
	eID += u<v?u:v;
    edge_set.insert(eID);

    
    E[edgeindex].u = u;
    E[edgeindex].v = v;
    E[edgeindex].p = p;
	if (trueedge) updatevertex(u);
	if (trueedge) updatevertex(v);
	if (V[u].deg >= V[u].neigsize) {
		cerr << "Error: Dynamic edge allocation full. Cannot allocate more dynamic edges for vertex "<<u<<"; it already has "<<V[u].deg<<" edges (its maximum)"<<endl;
		exit(0);
	}
	V[u].edges[V[u].deg] = &E[edgeindex];
	V[u].deg++;
	if (trueedge){
		V[u].outdeg++;
	} 
	if (trueedge) V[v].indeg++;
	if (trueedge) V[u].flag = 0;
	if (trueedge) V[v].flag = 0;
	edgeindex++;
	noedges++;
  }

  inline bool existedge(vertex *u, vertex *v){
  	  int32_t i,j;
	  i = u->id;
	  j = v->id;
	  int64_t eID = i>j?i:j;
	  eID = eID<<32;
	  eID += i<j?i:j;
	  return (edge_set.find(eID) != edge_set.end())?true : false;
  }
};
  
class Graph : public Gdb {

  private:

    void read_file(const char *file)
    {
		FILE *f;
		int32_t i,j;
        int32_t maxid = 0;
        int32_t p_reservedspaceE;
		char st[1000];
		
        p_reservedspaceE = 0;
		sprintf(st,"zcat %s",file);
		f = popen(st,"r");
		if (f == NULL) {
			cerr << "# Error opening file "<<file<<endl;
			exit(1);
		}
		while (!feof(f)) {
		  if (fscanf(f,"%d\t%d\n",&i,&j) == 2){
			  if (i != j) {
				  maxid = MAX(MAX(maxid,i+1),j+1);
				  p_reservedspaceE+=2;
			  }
		  }
		}
        pclose(f);
		if (maxid == 0) {
			cerr << "# Error with graph file "<<file<<endl;
			exit(1);
		}
        init(p_reservedspaceE,maxid+1);
        f = popen(st,"r");
        while (!feof(f)) {
          if (fscanf(f,"%d\t%d\n",&i,&j) == 2){
			  if (i != j) {
//				cerr << "edge ("<<i<<","<<j<<")"<<endl;
				addedge(i+1,j+1,DIRECTED_GRAPH_EDGE_FLAG,true);
				// creates edge j->i (because the graph is directed! and we need an undirected graph)
				addedge(j+1,i+1,INVALID_EDGE_FLAG,false);				
			  }
          }
        }
        pclose(f);
 	}
 
  public: 
	
	Graph(const char *filename) 
    :Gdb()
    { 
	  read_file(filename);
	}
	
	~Graph() {
	}
    
};

class MOSS3 {
	private:
		Graph *G;
		int64_t B3max;
		double StdErrMax;
		int64_t W;
		int64_t *W_array;
		int32_t *vertex_ids;
		int32_t size_W_array;

		
	public:
		MOSS3(Graph *pG, int64_t  b3max, double stdErrMax) {
			G = pG;
			B3max = b3max;
			StdErrMax = stdErrMax;
			W_array = (int64_t *) zalloc(G->size()* sizeof(int64_t));
			vertex_ids = (int32_t *) zalloc(G->size()* sizeof(int32_t));
		}
		~MOSS3(){
				free(W_array);
				free(vertex_ids);
		}

		void compute_weights() {
					
		  	vertex *v;
			int64_t W_v, acc_W_v;
			int64_t d;
			
			acc_W_v = 0;
			size_W_array = 0;

		
			G->vertex_iterator_start();
			while ((v = G->next_vertex()) != NULL) 
			{

				d = v->deg;
				W_v = (d-1) * (d-2)/2;
				if(W_v == 0) continue;
				acc_W_v += W_v ;
				W_array[size_W_array] = acc_W_v;
				vertex_ids[size_W_array] = v->id;
				size_W_array++;
			}
			W = acc_W_v;
		}

		void sampling(){
			int64_t rnd_weight;
			int32_t i, B3, batchsize;
			vertex *v, *u, *w;
			int64_t trianglecnt;
			double t1, t2, StdErr1, StdErr2;
			
			trianglecnt = 0;
			batchsize = 1000;

			for(B3=0; B3 < B3max; B3++)
			{
			 	rnd_weight = myrand<int64_t>(W) + 1;
			 	i = bineary_search(W_array, size_W_array, rnd_weight);
				v = G->getvertex(vertex_ids[i]);
				
				u = G->getrandomneighbor(v);

				do{
					w = G->getrandomneighbor(v);
				}while(w==u);

				if(G->existedge(u,w)) trianglecnt++;
				if (B3>0 && B3%batchsize == 0){
					t2 = W * trianglecnt;
					t2 = t2  / (3.0 * B3);
					t1 = W - 3 * t2;
					StdErr1 = sqrt(t2/3/t1/B3);
					StdErr2 = sqrt(t1/3/t2/B3);
					if(StdErr1 < StdErrMax && StdErr2 < StdErrMax){
						cerr << "t1:"<<t1<<'\t'<<"t2:" <<t2<<'\t'<<"StdErr1:" <<StdErr1<<'\t'<<"StdErr2:" <<StdErr2<<endl;
						return;
					}
				}
			}
			t2 = W * trianglecnt;
			t2 = t2  / (3.0 * B3);
			t1 = W - 3 * t2;
			StdErr1 = sqrt(t2/3/t1/B3);
			StdErr2 = sqrt(t1/3/t2/B3);
			cerr << "t1:"<<t1<<'\t'<<"t2:" <<t2<<'\t'<<"StdErr1:" <<StdErr1<<'\t'<<"StdErr2:" <<StdErr2<<endl;
		}
};



int main(int argc, char *argv[]) {
	Graph *G;
	MOSS3 *moss3;
	int32_t B3max;
	char *filename;
	double StdErrMax;
	
	if (argc != 4) {
		cerr << "Missing parameters:\n" <<
		"   <filename>: trace file name\n" <<
		"   <B3max>: maximum sampling budget of MOSS3\n" <<
		"   <StdErrMax>: desired StdErr of NOSS3\n" << endl;	
		exit(1);
	}
	filename = argv[1];
	B3max = atoi(argv[2]);
	StdErrMax = atof(argv[3]);
	
	cerr.precision(15);
	cerr.setf(ios::scientific,ios::floatfield);
	
	cerr << "#Reading the graph file on disk and building its adjacent list in memory...\n";
	clock_t start_t = clock();
	G = new Graph(filename);
	clock_t end_t = clock();
	cerr << "#Finished reading the graph file on disk and building its adjacent list in memory...\n";
	cerr << "#Number of edges = " << G->no_edges() << endl;
	cerr << "#Number of vertices = " << G->size() << endl;
	cerr <<"Time of reading the graph file on disk and building its adjacent list in memory = "<<(float)(end_t-start_t)/CLOCKS_PER_SEC<<" seconds"<<endl;
	

	cerr << "Starting sampling 3-node CISes..." << endl;
	start_t = clock();
	
	moss3 = new MOSS3(G, B3max, StdErrMax);
	moss3->compute_weights();
	moss3->sampling();

	end_t = clock();
    cerr <<"Time of sampling and estimating motif frequencies = "<<(float)(end_t-start_t)/CLOCKS_PER_SEC<<" seconds"<<endl;

	if (moss3 != NULL) delete moss3;	

	
	delete G;
	return 0;
}

